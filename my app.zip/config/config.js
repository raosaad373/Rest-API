module.exports = {
    url: 'mongodb+srv://saadii:success1636@mydata-ddjmf.mongodb.net/test?retryWrites=true&w=majority'
}